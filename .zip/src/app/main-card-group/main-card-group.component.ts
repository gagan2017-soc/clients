import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-card-group',
  templateUrl: './main-card-group.component.html',
  styleUrls: ['./main-card-group.component.css']
})
export class MainCardGroupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
