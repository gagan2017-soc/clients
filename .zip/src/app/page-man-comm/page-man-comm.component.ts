import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-man-comm',
  templateUrl: './page-man-comm.component.html',
  styleUrls: ['./page-man-comm.component.css']
})
export class PageManCommComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
