import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-fes-cal',
  templateUrl: './page-fes-cal.component.html',
  styleUrls: ['./page-fes-cal.component.css']
})
export class PageFesCalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
