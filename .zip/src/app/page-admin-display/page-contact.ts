import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-contact',
  templateUrl: './page-contact.html',
  styleUrls: ['./page-contact.css']
})
export class PageContact implements OnInit {

  constructor() {
    
   }

  ngOnInit(): void {
  }

}
