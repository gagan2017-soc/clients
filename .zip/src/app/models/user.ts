export class User {
    firstname: string;
    lastname: string;
    email: string;
    phoneno: number;
    password: string;
    wing: string;
    flatno:number;
    status :boolean;
    createdat: Date;
  }