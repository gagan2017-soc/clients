export class Transcation {
    entrydt:Date;
    narration:String;
    clearingdt:Date;
    amount:Number;
    mode: String;
    flatno:String;
    frommonth:String;
    fromyear:Number;
    tomonth:String;
    toyear:Number;
    receiptgen:string;
    receiptnumber:String;
  };