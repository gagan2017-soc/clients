import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-supp-staff',
  templateUrl: './page-supp-staff.component.html',
  styleUrls: ['./page-supp-staff.component.css']
})
export class PageSuppStaffComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
