import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-other-gallery',
  templateUrl: './page-other-gallery.component.html',
  styleUrls: ['./page-other-gallery.component.css']
})
export class PageOtherGalleryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
