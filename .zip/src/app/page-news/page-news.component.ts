import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-news',
  templateUrl: './page-news.component.html',
  styleUrls: ['./page-news.component.css']
})
export class PageNewsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
