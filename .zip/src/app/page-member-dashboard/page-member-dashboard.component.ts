import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-member-dashboard',
  templateUrl: './page-member-dashboard.component.html',
  styleUrls: ['./page-member-dashboard.component.css']
})
export class PageMemberDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
