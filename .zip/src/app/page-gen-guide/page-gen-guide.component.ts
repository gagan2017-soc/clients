import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-gen-guide',
  templateUrl: './page-gen-guide.component.html',
  styleUrls: ['./page-gen-guide.component.css']
})
export class PageGenGuideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
