import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-gan-gallery',
  templateUrl: './page-gan-gallery.component.html',
  styleUrls: ['./page-gan-gallery.component.css']
})
export class PageGanGalleryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
