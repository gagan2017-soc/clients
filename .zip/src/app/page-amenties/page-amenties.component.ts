import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-amenties',
  templateUrl: './page-amenties.component.html',
  styleUrls: ['./page-amenties.component.css']
})
export class PageAmentiesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
