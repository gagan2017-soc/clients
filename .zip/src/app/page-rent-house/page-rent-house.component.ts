import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-rent-house',
  templateUrl: './page-rent-house.component.html',
  styleUrls: ['./page-rent-house.component.css']
})
export class PageRentHouseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
